import React from 'react';
import styles from './AdminMainContainer.module.scss';

function AdminMainContainer() {
  return (
    <div>
      <div>
        <h1>관리자 메인페이지</h1>
      </div>
    </div>
  );
}

export default AdminMainContainer;
