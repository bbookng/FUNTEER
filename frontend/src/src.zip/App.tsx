import React from 'react';

// redux
// eslint-disable-next-line
import { increment, decrement } from './store/slices/counterSlice';
// eslint-disable-next-line
import { useAppDispatch, useAppSelector } from './store/hooks';

function App() {
  return (
    /**
     * path: 이동할 경로, element: 렌더링할 페이지
     */
    <div></div>
  );
}

export default App;
