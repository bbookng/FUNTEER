export type UserSignInType = {
  email: string;
  password: string;
  type:string
};
