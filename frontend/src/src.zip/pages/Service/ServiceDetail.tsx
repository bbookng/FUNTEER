import React from 'react';
import ServiceDetailContainer from '../../containers/Service/ServiceDetailContainer';

function ServiceDetail() {
  return <ServiceDetailContainer />;
}

export default ServiceDetail;
