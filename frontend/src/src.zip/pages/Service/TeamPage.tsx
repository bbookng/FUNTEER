import React from 'react';
import TeamPageContainer from '../../containers/Service/TeamPageContainer';

function TeamPage() {
  return <TeamPageContainer />;
}

export default TeamPage;
