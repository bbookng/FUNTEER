import React from 'react';
import ChargeContainer from '../../containers/AddOns/ChargeContainer';

function Charge() {
  return <ChargeContainer />;
}

export default Charge;
