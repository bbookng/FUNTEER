import React from 'react';
import ErrorPageContainer from '../../containers/AddOns/ErrorPageContainer';

function ErrorPage() {
  return <ErrorPageContainer />;
}

export default ErrorPage;
