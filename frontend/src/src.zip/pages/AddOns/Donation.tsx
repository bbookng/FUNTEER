import React from 'react';
import DonationContainer from '../../containers/Donation/DonationContainer';

function Donation() {
  return <DonationContainer />;
}

export default Donation;
