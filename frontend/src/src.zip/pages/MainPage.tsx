import React from 'react';
import MainPageContainer from '../containers/Main/MainPageContainer';

function MainPage() {
  return (
    <>
      <MainPageContainer />;
    </>
  );
}

export default MainPage;
