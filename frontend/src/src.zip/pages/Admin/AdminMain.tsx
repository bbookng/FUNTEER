import React from 'react';
import AdminMainContainer from '../../containers/Admin/AdminMainContainer';

function AdminMain() {
  return <AdminMainContainer />;
}

export default AdminMain;
