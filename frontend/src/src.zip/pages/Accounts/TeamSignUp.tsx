import React from 'react';
import TeamSignUpContainer from '../../containers/Accounts/TeamSignUpContainer';

function TeamSignUp() {
  return <TeamSignUpContainer />;
}

export default TeamSignUp;
