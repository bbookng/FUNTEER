import React from 'react';
import ResetPasswordContainer from '../../containers/Accounts/ResetPasswordContainer';

function ResetPassword() {
  return <ResetPasswordContainer />;
}

export default ResetPassword;
