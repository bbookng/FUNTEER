import React from 'react';
import MemberSignUpContainer from '../../containers/Accounts/MemberSignUpContainer';

function MemberSignUp() {
  return <MemberSignUpContainer />;
}

export default MemberSignUp;
