import React from 'react';
import FindEmailContainer from '../../containers/Accounts/FindEmailContainer';

function FindEmail() {
  return <FindEmailContainer />;
}
export default FindEmail;
