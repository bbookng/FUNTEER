import React from 'react';
import FindPasswordContainer from '../../containers/Accounts/FindPasswordContainer';

function FindPassword() {
  return <FindPasswordContainer />;
}

export default FindPassword;
