import React from 'react';
import LoginContainer from '../../containers/Accounts/LoginContainer';

function Login() {
  return <LoginContainer />;
}

export default Login;
