import React from 'react';
import MyFundingContainer from '../../containers/MyPage/MyFundingContainer';

function MyPage() {
  return <MyFundingContainer />;
}

export default MyPage;
