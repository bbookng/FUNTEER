import React from 'react';
import MyDonatesContainer from '../../containers/MyPage/MyDonatesContainer';

function MyPage() {
  return <MyDonatesContainer />;
}

export default MyPage;
