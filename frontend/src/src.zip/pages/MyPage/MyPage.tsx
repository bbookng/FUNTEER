import React from 'react';
import MyPageContainer from '../../containers/MyPage/MyPageContainer';

function MyPage() {
  return <MyPageContainer />;
}

export default MyPage;
