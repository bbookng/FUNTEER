import React from 'react';
import MyFunteerDonatesContainer from '../../containers/MyPage/MyFunteerDonatesContainer';

function MyPage() {
  return <MyFunteerDonatesContainer />;
}

export default MyPage;
