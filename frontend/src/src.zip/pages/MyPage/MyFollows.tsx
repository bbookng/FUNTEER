import React from 'react';
import MyFollowsContainer from '../../containers/MyPage/MyFollowsContainer';

function MyPage() {
  return <MyFollowsContainer />;
}

export default MyPage;
