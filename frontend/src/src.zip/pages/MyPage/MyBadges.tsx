import React from 'react';
import MyBadgesContainer from '../../containers/MyPage/MyBadgesContainer';

function MyPage() {
  return <MyBadgesContainer />;
}

export default MyPage;
