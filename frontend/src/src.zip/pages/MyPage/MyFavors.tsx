import React from 'react';
import MyFavorsContainer from '../../containers/MyPage/MyFavorsContainer';

function MyPage() {
  return <MyFavorsContainer />;
}

export default MyPage;
