import React from 'react';
import EditProfileContainer from '../../containers/MyPage/EditProfileContainer';

function MyPage() {
  return <EditProfileContainer />;
}

export default MyPage;
